NOTE: This directory does NOT have a package.json file.

The package.json file is created by src/test/addons-test.js as needed.

This way we aren't modifying a file that's under source code control.
