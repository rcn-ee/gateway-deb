gateway_addon
=============

Python bindings for developing Python add-ons for Mozilla WebThings Gateway.

For a tutorial on building an add-on, see `this page <https://hacks.mozilla.org/2018/02/creating-an-add-on-for-the-project-things-gateway/>`_.
